export interface DataValue {
    value: number;
}
