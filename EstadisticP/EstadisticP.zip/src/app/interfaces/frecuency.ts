export interface Frequency {
    value: number;
    f?: number;
    fr?: number;
    fPercent?: number;
    fa?: number;
}
